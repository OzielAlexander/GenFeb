/* =============================================
   POMO — Premium Focus Timer v4
   Alarmas temáticas + Stats rediseñadas
   ============================================= */
"use strict";

// ─── ALARMAS POR TEMA ────────────────────────────
// Cada tema tiene sonidos temáticos. Usamos URLs de mixkit (gratuitas).
const THEME_SOUNDS = {
    sakura: [
        { id: 'koto',    icon: '🎋', name: 'Koto',        url: 'https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3' },
        { id: 'wind',    icon: '🌬', name: 'Wind Chime',   url: 'https://assets.mixkit.co/active_storage/sfx/2580/2580-preview.mp3' },
        { id: 'bell',    icon: '🔔', name: 'Soft Bell',    url: 'https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3' },
    ],
    ocean: [
        { id: 'waves',   icon: '🌊', name: 'Waves',        url: 'https://assets.mixkit.co/active_storage/sfx/2580/2580-preview.mp3' },
        { id: 'sonar',   icon: '🔭', name: 'Sonar Ping',   url: 'https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3' },
        { id: 'bubble',  icon: '🫧', name: 'Bubbles',      url: 'https://assets.mixkit.co/active_storage/sfx/2580/2580-preview.mp3' },
    ],
    inferno: [
        { id: 'fire',    icon: '🔥', name: 'Ember Crack',  url: 'https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3' },
        { id: 'horn',    icon: '📯', name: 'War Horn',     url: 'https://assets.mixkit.co/active_storage/sfx/2580/2580-preview.mp3' },
        { id: 'anvil',   icon: '⚒️', name: 'Anvil Strike', url: 'https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3' },
    ],
    heaven: [
        { id: 'harp',    icon: '🎶', name: 'Angel Harp',   url: 'https://assets.mixkit.co/active_storage/sfx/2580/2580-preview.mp3' },
        { id: 'choir',   icon: '👼', name: 'Choir Bell',   url: 'https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3' },
        { id: 'crystal', icon: '🔮', name: 'Crystal',      url: 'https://assets.mixkit.co/active_storage/sfx/2580/2580-preview.mp3' },
    ],
    jungle: [
        { id: 'bird',    icon: '🦜', name: 'Tropical Bird',url: 'https://assets.mixkit.co/active_storage/sfx/2580/2580-preview.mp3' },
        { id: 'drum',    icon: '🥁', name: 'Tribal Drum',  url: 'https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3' },
        { id: 'frog',    icon: '🐸', name: 'Night Frog',   url: 'https://assets.mixkit.co/active_storage/sfx/2580/2580-preview.mp3' },
    ],
    void: [
        { id: 'synth',   icon: '🌌', name: 'Synth Wave',   url: 'https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3' },
        { id: 'pulse',   icon: '⚡', name: 'Cosmic Pulse', url: 'https://assets.mixkit.co/active_storage/sfx/2580/2580-preview.mp3' },
        { id: 'glitch',  icon: '👾', name: 'Glitch',       url: 'https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3' },
    ]
};

// ─── STATE ──────────────────────────────────────
const STATE = {
    timer:     null,
    timeLeft:  25 * 60,
    totalTime: 25 * 60,
    isRunning: false,
    mode:      'pomo',
    sessions:  1,
    alarm: {
        selectedId: null,   // ID del sonido seleccionado (null = primer sonido del tema)
        customUrl:  null,   // URL blob si el usuario subió audio
        volume:     0.8
    },
    stats: {
        pomos:      0,
        minutes:    0,
        tasks:      0,
        streak:     0,
        lastDate:   null,
        heatmap:    {},
        todayPomos: 0,
        lastResetDate: null
    },
    dailyGoal: 8,
    tasks: []
};

const MODES = {
    pomo:  { time: 25 * 60, label: 'Focus',       msg: 'Una tarea. Plena atención.',       short: 'FOCUS' },
    short: { time:  5 * 60, label: 'Short Break',  msg: 'Respira. Estira. Vuelves pronto.', short: 'SHORT' },
    long:  { time: 15 * 60, label: 'Long Break',   msg: 'Descanso merecido. Sin culpas.',   short: 'LONG'  }
};

// ─── PARTÍCULAS ──────────────────────────────────
const PARTICLES = {
    sakura:  { chars: ['🌸','🌸','✿','❀','·','·'], colors: ['#ffb7c5','#e8829a','#fde8ed'], speed: 0.6, size: [10,18], drift: 0.8, spin: true },
    ocean:   { chars: ['·','·','∘','○','◦','∙'], colors: ['#7dd3fc','#38bdf8','#bae6fd','#ffffff'], speed: 0.4, size: [3,10], drift: 0.3, spin: false },
    inferno: { chars: ['·','·','∙','°','·'], colors: ['#f97316','#fbbf24','#dc2626','#ff4444'], speed: 1.2, size: [2,8], drift: 0.5, spin: false },
    heaven:  { chars: ['✦','✧','·','⋆','✦','·','·'], colors: ['#ffffff','#e0d7ff','#c4b5fd','#f5f0ff'], speed: 0.3, size: [4,14], drift: 0.4, spin: false },
    jungle:  { chars: ['·','·','∙','∘','·'], colors: ['#4ade80','#86efac','#22c55e','#bbf7d0'], speed: 0.5, size: [3,9], drift: 0.6, spin: false },
    void:    { chars: ['✦','·','∙','⋆','·','✦','·'], colors: ['#818cf8','#a5b4fc','#ffffff','#c7d2fe'], speed: 0.25, size: [2,10], drift: 0.2, spin: false }
};

const canvas = document.getElementById('particleCanvas');
const ctx    = canvas.getContext('2d');
let particles = [];
let currentTheme = 'sakura';

function resizeCanvas() { canvas.width = window.innerWidth; canvas.height = window.innerHeight; }

function createParticle(cfg) {
    return {
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height + 20,
        char:  cfg.chars[Math.floor(Math.random() * cfg.chars.length)],
        color: cfg.colors[Math.floor(Math.random() * cfg.colors.length)],
        size:  cfg.size[0] + Math.random() * (cfg.size[1] - cfg.size[0]),
        speedY: cfg.speed * (0.5 + Math.random()),
        driftX: (Math.random() - 0.5) * cfg.drift,
        alpha:  0.5 + Math.random() * 0.5,
        rot:    Math.random() * Math.PI * 2,
        rotSpeed: cfg.spin ? (Math.random() - 0.5) * 0.05 : 0,
        wave: Math.random() * Math.PI * 2,
        waveAmp: 0.3 + Math.random() * 0.7
    };
}

function spawnParticles(theme) {
    const cfg = PARTICLES[theme] || PARTICLES.sakura;
    const count = theme === 'void' ? 80 : theme === 'heaven' ? 60 : 40;
    particles = Array.from({ length: count }, () => createParticle(cfg));
}

function animateParticles() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const cfg = PARTICLES[currentTheme] || PARTICLES.sakura;
    particles.forEach(p => {
        p.y -= p.speedY;
        p.x += Math.sin(p.wave) * p.waveAmp + p.driftX;
        p.wave += 0.02;
        p.rot += p.rotSpeed;
        if (p.y < -30) { p.y = canvas.height + 20; p.x = Math.random() * canvas.width; }
        ctx.save();
        ctx.globalAlpha = p.alpha;
        ctx.font = `${p.size}px serif`;
        ctx.fillStyle = p.color;
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rot);
        ctx.fillText(p.char, -p.size / 2, p.size / 2);
        ctx.restore();
    });
    requestAnimationFrame(animateParticles);
}

// ─── HELPERS ────────────────────────────────────
const $ = id => document.getElementById(id);
const $$ = sel => document.querySelectorAll(sel);
const pad = n => String(n).padStart(2, '0');
const fmt = s => `${pad(Math.floor(s / 60))}:${pad(s % 60)}`;

function saveData() {
    localStorage.setItem('pomo_v4', JSON.stringify({
        stats:     STATE.stats,
        tasks:     STATE.tasks,
        alarm:     { selectedId: STATE.alarm.selectedId, volume: STATE.alarm.volume },
        dailyGoal: STATE.dailyGoal
    }));
}

function loadData() {
    try {
        const d = JSON.parse(localStorage.getItem('pomo_v4') || '{}');
        if (d.stats)     Object.assign(STATE.stats, d.stats);
        if (d.tasks)     STATE.tasks = d.tasks;
        if (d.alarm)     Object.assign(STATE.alarm, d.alarm);
        if (d.dailyGoal) STATE.dailyGoal = d.dailyGoal;

        // Resetear today pomos si es un día nuevo
        const today = new Date().toDateString();
        if (STATE.stats.lastResetDate !== today) {
            STATE.stats.todayPomos = 0;
            STATE.stats.lastResetDate = today;
        }
    } catch(e) {}
}

// ─── TOAST ──────────────────────────────────────
function toast(msg, dur = 2800) {
    const el = document.createElement('div');
    el.className = 'toast'; el.textContent = msg;
    $('toastContainer').appendChild(el);
    setTimeout(() => {
        el.style.animation = 'toastOut 0.3s ease forwards';
        el.addEventListener('animationend', () => el.remove(), { once: true });
    }, dur);
}

// ─── AUDIO ──────────────────────────────────────
const audioEl = $('alarmSound');

function getCurrentSoundUrl() {
    if (STATE.alarm.customUrl) return STATE.alarm.customUrl;
    const sounds = THEME_SOUNDS[currentTheme] || THEME_SOUNDS.sakura;
    // Si hay un ID guardado que existe en este tema, usarlo; si no, el primero
    const found = sounds.find(s => s.id === STATE.alarm.selectedId);
    return (found || sounds[0]).url;
}

function playAlarm() {
    audioEl.src = getCurrentSoundUrl();
    audioEl.volume = STATE.alarm.volume;
    audioEl.currentTime = 0;
    audioEl.play().catch(() => {});
}

function renderAlarmPanel(theme) {
    const panel = $('alarmSounds');
    const sounds = THEME_SOUNDS[theme] || THEME_SOUNDS.sakura;
    panel.innerHTML = '';

    // Determinar cuál está seleccionado
    const activeId = STATE.alarm.customUrl
        ? '__custom__'
        : (sounds.find(s => s.id === STATE.alarm.selectedId) ? STATE.alarm.selectedId : sounds[0].id);

    sounds.forEach(s => {
        const btn = document.createElement('button');
        btn.className = 'alarm-sound-btn' + (s.id === activeId ? ' active' : '');
        btn.dataset.id = s.id;
        btn.innerHTML = `<span class="sound-icon">${s.icon}</span><span>${s.name}</span>`;
        btn.addEventListener('click', () => {
            STATE.alarm.selectedId = s.id;
            STATE.alarm.customUrl  = null;
            $('uploadLabel').textContent = 'Subir audio';
            document.querySelector('.alarm-upload-btn')?.classList.remove('has-file');
            renderAlarmPanel(currentTheme);
            saveData();
            toast(`🔔 Alarma: ${s.name}`);
        });
        panel.appendChild(btn);
    });
}

// Volumen
$('volumeSlider').addEventListener('input', e => {
    STATE.alarm.volume = parseFloat(e.target.value);
    audioEl.volume = STATE.alarm.volume;
    saveData();
});

// Upload custom audio
$('alarmUpload').addEventListener('change', e => {
    const file = e.target.files[0];
    if (!file) return;
    if (STATE.alarm.customUrl) URL.revokeObjectURL(STATE.alarm.customUrl);
    STATE.alarm.customUrl = URL.createObjectURL(file);
    STATE.alarm.selectedId = '__custom__';
    const name = file.name.length > 14 ? file.name.substring(0,12) + '…' : file.name;
    $('uploadLabel').textContent = name;
    document.querySelector('.alarm-upload-btn')?.classList.add('has-file');
    renderAlarmPanel(currentTheme);
    saveData();
    toast(`✓ Audio cargado: ${file.name}`);
});

// Preview
$('previewAlarmBtn').addEventListener('click', () => {
    audioEl.src = getCurrentSoundUrl();
    audioEl.volume = STATE.alarm.volume;
    audioEl.currentTime = 0;
    audioEl.play().catch(() => toast('⚠ No se pudo reproducir el audio'));
});

// ─── DISPLAY ────────────────────────────────────
function updateDisplay() {
    $('timer').textContent = fmt(STATE.timeLeft);
    document.title = `${fmt(STATE.timeLeft)} — POMO`;
    const progress = STATE.timeLeft / STATE.totalTime;
    const offset   = 816.81 - (progress * 816.81);
    $('ringFill').style.strokeDashoffset = offset;
    $('timer').classList.toggle('low-time', STATE.timeLeft <= 60 && STATE.timeLeft > 0);
}

function updateSessionDots() {
    const dots = $('sessionDots').querySelectorAll('.s-dot');
    const idx  = (STATE.sessions - 1) % 4;
    dots.forEach((d, i) => {
        d.classList.remove('active', 'done');
        if (i < idx)   d.classList.add('done');
        if (i === idx) d.classList.add('active');
    });
}

// ─── TIMER ──────────────────────────────────────
function startTimer() {
    if (STATE.isRunning) { pauseTimer(); return; }
    STATE.isRunning = true;
    $('iconPlay').classList.add('hidden');
    $('iconPause').classList.remove('hidden');
    $('skipBtn').classList.remove('hidden');
    STATE.timer = setInterval(() => {
        STATE.timeLeft--;
        updateDisplay();
        if (STATE.timeLeft <= 0) handleEnd();
    }, 1000);
}

function pauseTimer() {
    clearInterval(STATE.timer);
    STATE.isRunning = false;
    $('iconPlay').classList.remove('hidden');
    $('iconPause').classList.add('hidden');
    $('skipBtn').classList.add('hidden');
}

function resetTimer() {
    pauseTimer();
    STATE.timeLeft  = MODES[STATE.mode].time;
    STATE.totalTime = STATE.timeLeft;
    updateDisplay();
}

function switchMode(mode) {
    STATE.mode      = mode;
    STATE.timeLeft  = MODES[mode].time;
    STATE.totalTime = MODES[mode].time;
    document.body.classList.remove('mode-pomo', 'mode-short', 'mode-long');
    document.body.classList.add(`mode-${mode}`);
    $$('.pill').forEach(p => p.classList.toggle('active', p.dataset.mode === mode));
    $('modeLabelInner').textContent = MODES[mode].short;
    $('statusMsg').textContent = MODES[mode].msg;
    pauseTimer();
    updateDisplay();
}

// ─── SESSION END ────────────────────────────────
function handleEnd() {
    pauseTimer();
    playAlarm();

    const colorsByTheme = {
        sakura:  ['#ffb7c5','#e8829a','#fde8ed','#fff'],
        ocean:   ['#0ea5e9','#7dd3fc','#bae6fd','#fff'],
        inferno: ['#f97316','#fbbf24','#dc2626','#ffcc00'],
        heaven:  ['#a78bfa','#c4b5fd','#ffffff','#e0d7ff'],
        jungle:  ['#22c55e','#4ade80','#86efac','#fff'],
        void:    ['#818cf8','#a5b4fc','#6366f1','#fff']
    };
    confetti({ particleCount: 130, spread: 80, origin: { y: 0.55 }, colors: colorsByTheme[currentTheme] || ['#fff'] });

    if (STATE.mode === 'pomo') {
        STATE.stats.pomos++;
        STATE.stats.minutes += 25;
        STATE.stats.todayPomos++;
        const h = new Date().getHours();
        STATE.stats.heatmap[h] = (STATE.stats.heatmap[h] || 0) + 1;
        const today = new Date().toDateString();
        const yesterday = new Date(Date.now() - 86400000).toDateString();
        if (STATE.stats.lastDate !== today) {
            STATE.stats.streak = STATE.stats.lastDate === yesterday ? STATE.stats.streak + 1 : 1;
            STATE.stats.lastDate = today;
        }
        STATE.sessions++;
        $('sessionLabel').textContent = `#${STATE.sessions}`;
        updateSessionDots();
    }

    saveData();
    renderStats();

    const nextMode = STATE.mode === 'pomo'
        ? (STATE.sessions % 4 === 0 ? 'long' : 'short')
        : 'pomo';

    const msgs = { pomo: '✦ Pomodoro completado.', short: '✦ Descanso listo.', long: '✦ Gran descanso.' };
    toast(msgs[STATE.mode]);

    setTimeout(() => { switchMode(nextMode); startTimer(); }, 1800);
}

// ─── THEMES ─────────────────────────────────────
function setTheme(theme) {
    ['sakura','ocean','inferno','heaven','jungle','void'].forEach(t => document.body.classList.remove(`theme-${t}`));
    document.body.classList.add(`theme-${theme}`);
    currentTheme = theme;
    localStorage.setItem('pomo_theme', theme);
    $$('.theme-btn').forEach(b => b.classList.toggle('active', b.dataset.theme === theme));
    spawnParticles(theme);
    renderAlarmPanel(theme);
}

// ─── VIEWS ──────────────────────────────────────
function switchView(view) {
    $$('.view').forEach(v => v.classList.remove('active'));
    $$('.nav-item').forEach(n => n.classList.remove('active'));
    $(`view-${view}`).classList.add('active');
    document.querySelector(`[data-view="${view}"]`).classList.add('active');
    if (view === 'stats') renderStats();
    if (view === 'tasks') renderTasks();
}

// ─── TASKS ──────────────────────────────────────
function escapeHtml(s) {
    return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function renderTasks() {
    const list = $('taskList');
    list.innerHTML = '';
    $('emptyHint').classList.toggle('hidden', STATE.tasks.length > 0);
    STATE.tasks.forEach((task, i) => {
        const div = document.createElement('div');
        div.className = 'task-item' + (task.done ? ' completed' : '');
        div.innerHTML = `
            <div class="task-check"></div>
            <span class="task-text">${escapeHtml(task.text)}</span>
            <button class="task-delete" title="Eliminar">✕</button>
        `;
        const toggle = () => {
            STATE.tasks[i].done = !STATE.tasks[i].done;
            if (STATE.tasks[i].done) { STATE.stats.tasks++; saveData(); renderStats(); }
            renderTasks(); saveData();
        };
        div.addEventListener('click', e => { if (e.target.tagName !== 'BUTTON') toggle(); });
        div.querySelector('.task-check').addEventListener('click', e => { e.stopPropagation(); toggle(); });
        div.querySelector('.task-delete').addEventListener('click', e => {
            e.stopPropagation(); STATE.tasks.splice(i, 1); renderTasks(); saveData();
        });
        list.appendChild(div);
    });
}

$('openModalBtn').addEventListener('click', async () => {
    const accent = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#c9607a';
    const { value } = await Swal.fire({
        title: 'Nueva Tarea', input: 'text',
        inputPlaceholder: 'Ej: Terminar informe del proyecto...',
        confirmButtonText: 'Agregar', cancelButtonText: 'Cancelar',
        showCancelButton: true, confirmButtonColor: accent,
        inputAttributes: { maxlength: 120 }
    });
    if (value && value.trim()) {
        STATE.tasks.push({ text: value.trim(), done: false });
        renderTasks(); saveData();
        toast('✓ Tarea agregada');
    }
});

// ─── STATS ──────────────────────────────────────
function renderStats() {
    $('statPomos').textContent   = STATE.stats.pomos;
    $('statMinutes').textContent = STATE.stats.minutes;
    $('statTasks').textContent   = STATE.stats.tasks;
    $('statStreak').textContent  = STATE.stats.streak;

    // Barras de progreso en tarjetas (relativo a meta de 200 pomos / 3000 min)
    const pomoPct = Math.min((STATE.stats.pomos / 200) * 100, 100);
    const minPct  = Math.min((STATE.stats.minutes / 3000) * 100, 100);
    const barPomos   = $('barPomos');
    const barMinutes = $('barMinutes');
    if (barPomos)   barPomos.style.width   = pomoPct + '%';
    if (barMinutes) barMinutes.style.width = minPct  + '%';

    // Objetivo diario
    const goal   = STATE.dailyGoal;
    const today  = STATE.stats.todayPomos || 0;
    const pct    = Math.min((today / goal) * 100, 100);
    $('goalTarget').textContent     = goal;
    $('dailyGoalCount').textContent = `${today} / ${goal}`;
    const fill = $('dailyProgressFill');
    if (fill) {
        fill.style.width = pct + '%';
        fill.classList.toggle('active', pct > 0 && pct < 100);
    }
    const sub = $('dailyGoalSub');
    if (sub) {
        if (today === 0)        sub.textContent = '¡Comienza tu primer pomodoro del día!';
        else if (pct >= 100)    sub.textContent = `🎉 ¡Meta diaria cumplida! ${today} pomodoros.`;
        else {
            const left = goal - today;
            sub.textContent = `${left} pomodoro${left !== 1 ? 's' : ''} más para alcanzar tu meta.`;
        }
    }

    renderHeatmap();
    renderInsight();
}

function renderHeatmap() {
    const hm = $('heatmap');
    hm.innerHTML = '';
    for (let h = 0; h < 24; h++) {
        const block = document.createElement('div');
        block.className = 'heat-block';
        const count = Math.min(STATE.stats.heatmap[h] || 0, 4);
        if (count > 0) block.dataset.count = count;
        block.title = `${pad(h)}:00 — ${count} pomo${count !== 1 ? 's' : ''}`;
        hm.appendChild(block);
    }
}

function renderInsight() {
    const heatmap = STATE.stats.heatmap;
    const entries = Object.entries(heatmap).map(([h, c]) => ({ h: parseInt(h), c }));
    if (entries.length === 0) return;
    entries.sort((a, b) => b.c - a.c);
    const best = entries[0];
    const hourStr = `${pad(best.h)}:00 – ${pad(best.h + 1)}:00`;
    $('insightTitle').textContent = `Tu hora pico: ${hourStr}`;
    $('insightSub').textContent   = `${best.c} pomodoro${best.c !== 1 ? 's' : ''} en esa hora · ¡Planifica tus tareas importantes ahí!`;
}

// Objetivo: ajustar meta
$('goalMinus').addEventListener('click', () => {
    if (STATE.dailyGoal > 1) { STATE.dailyGoal--; saveData(); renderStats(); }
});
$('goalPlus').addEventListener('click', () => {
    if (STATE.dailyGoal < 20) { STATE.dailyGoal++; saveData(); renderStats(); }
});

// Reset stats
$('resetStatsBtn').addEventListener('click', async () => {
    const accent = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#c9607a';
    const { isConfirmed } = await Swal.fire({
        title: '¿Resetear estadísticas?', text: 'Esta acción es irreversible.',
        icon: 'warning', showCancelButton: true,
        confirmButtonText: 'Sí, resetear', cancelButtonText: 'Cancelar',
        confirmButtonColor: accent
    });
    if (isConfirmed) {
        STATE.stats = { pomos:0, minutes:0, tasks:0, streak:0, lastDate:null, heatmap:{}, todayPomos:0, lastResetDate: new Date().toDateString() };
        saveData(); renderStats();
        toast('Estadísticas reseteadas');
    }
});

// ─── EVENTOS ────────────────────────────────────
$('startBtn').addEventListener('click', startTimer);
$('resetBtn').addEventListener('click', resetTimer);
$('skipBtn').addEventListener('click',  () => { STATE.timeLeft = 0; handleEnd(); });
$$('.pill').forEach(btn => btn.addEventListener('click', () => switchMode(btn.dataset.mode)));
$$('.nav-item').forEach(btn => btn.addEventListener('click', () => switchView(btn.dataset.view)));
$$('.theme-btn').forEach(btn => btn.addEventListener('click', () => setTheme(btn.dataset.theme)));
document.addEventListener('keydown', e => {
    if (e.target.tagName === 'INPUT') return;
    if (e.code === 'Space') { e.preventDefault(); startTimer(); }
    if (e.code === 'KeyR')  resetTimer();
});
window.addEventListener('resize', resizeCanvas);

// ─── INIT ────────────────────────────────────────
function init() {
    loadData();
    resizeCanvas();

    const savedTheme = localStorage.getItem('pomo_theme') || 'sakura';
    setTheme(savedTheme);  // También llama renderAlarmPanel

    // Restaurar volumen
    $('volumeSlider').value = STATE.alarm.volume;

    $('sessionLabel').textContent = `#${STATE.sessions}`;
    updateSessionDots();
    switchMode('pomo');
    renderTasks();
    renderStats();
    animateParticles();

    setTimeout(() => toast('✦ Space · play/pause  ·  R · reiniciar'), 1000);
}

init();
